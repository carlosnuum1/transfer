# Webpack dashboard

> Dashboard & analyzer components for @vue/cli-ui

```
yarn serve
yarn build
```
