# @vue/cli-service-global

Installing this package globally allows you to run `vue serve` and `vue build` directly without any local dependencies:

``` sh
npm install -g @vue/cli-service-global
echo '<template><h1>Hello!</h1></template>' > App.vue
vue serve
```
