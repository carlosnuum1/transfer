export default {
  connected: true,
  loading: 0,
  darkMode: false,
  currentProjectId: null
}
